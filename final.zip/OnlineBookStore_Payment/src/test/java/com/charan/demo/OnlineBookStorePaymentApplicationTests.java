package com.charan.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookStorePaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
