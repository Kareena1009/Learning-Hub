package com.joshi.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class OnlineBookStoreAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBookStoreAdminApplication.class, args);
	}

}
