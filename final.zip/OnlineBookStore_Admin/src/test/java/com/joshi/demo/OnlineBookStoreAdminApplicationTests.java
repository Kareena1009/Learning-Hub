package com.joshi.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookStoreAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
